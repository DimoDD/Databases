﻿using System;

namespace CommonFiles
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
