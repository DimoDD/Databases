﻿namespace CommonFiles
{
    public static class Configuration
    {
        public static string connectionParams = "Server=.; Database=MinionsDB; Integrated Security=true; MultipleActiveResultSets=true;";
    }
}